import psutil


def get_memory_usage():
    """Returns the current memory usage as a percentage."""
    memory_info = psutil.virtual_memory()
    return memory_info.percent
