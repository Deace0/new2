import psutil


def get_disk_usage():
    """Returns the current disk usage as a percentage."""
    disk_info = psutil.disk_usage("/")
    return disk_info.percent
